﻿internal interface IUseable
{
    void Use();
}